from selenium import webdriver # 웹 열기
from time import sleep as sleep # 멈춰

options = webdriver.ChromeOptions() # 모름

options.add_experimental_option('excludeSwitches', ['enable-logging']) # 모름

dr = webdriver.Chrome(options=options) # 크롬 오픈

dr.maximize_window # 윈도우 창 최대

dr.get('https://arca.live/u/login') # 로그인 접속
print("로그인 완료 시 엔터를 누르세요.")
input()
dr.get('https://arca.live/b/thermometer') # 라이브 온도계 접속
print("회차 진행 5초 전 실행하다 오류 발생 시 책임 질 수 없습니다.")
input()
print("숫자를 물을 때 이상한 숫자를 적어 생기는 오류는 책임지지 못합니다.")
input()
first_pt = int(input("처음에 걸 포인트(100pt ~ 1,000,000pt 사이)")) # 처음에 걸 포인트
input_pt = int(first_pt) # 넣을 포인트 = 처음에 걸 포인트
hz = int(input("홀짝 여부(1: 홀, 2: 짝)"))
goback = 0 # 온도 100, 0일시 돌아가는 변수 미리 만들어놓음
while(True):
    goback = 0 # 온도 100, 0일시 돌아가는 변수 초기화
    dr.find_element("xpath",'//*[@id="doplay"]/div/div[2]/input').send_keys(input_pt) # 금액 넣기
    if hz == 1:
        dr.find_element("xpath",'//*[@id="doplay"]/div/div[3]/div[2]/p[3]/span[1]').click() # 홀수
    else:
        dr.find_element("xpath",'//*[@id="doplay"]/div/div[3]/div[2]/p[3]/span[2]').click() # 짝수

    if dr.find_element("xpath",'/html/body/div[2]/div[3]/article/div/div[2]/div/div/button'):
        dr.find_element("xpath",'/html/body/div[2]/div[3]/article/div/div[2]/div/div/button').click()
    sleep(60)
    input_temper = dr.find_element("xpath",'/html/body/div/div[3]/article/div[1]/div[1]/div/div/div[2]/div[4]/div[1]').text # 온도 따오기
    mid_temper = input_temper[:3] # 3글자만 남기기
    output_temper = mid_temper.replace('°', '') # ° 없애기
    output_temper = output_temper.replace('C', '') # C 없애기
    output_temper = output_temper.replace('(', '') # 혹시 모르니 ( 없애기
    if output_temper == '0': # 온도 0일시 되돌아가기
        input_pt*=2
        goback = 1
    elif output_temper == '100': # 온도 100일시 돌아가기
        input_pt*=2
        goback = 1
    elif goback == 0: # 온도 100도나 0도 아닐 시 실행
        if int(output_temper) % 2 == 0: # 만약 온도가 짝수일 시
            if hz == 1: # 만약 처음에 홀수를 선택했다면
                input_pt*=2 # 넣을 포인트에 x2
            if hz == 2: # 만약 처음에 짝수를 선택했다면
                input_pt = first_pt # 넣을 포인트 초기화
        if int(output_temper) % 2 == 1: # 만약 온도가 홀수일 시
            if hz == 1: # 만약 처음에 홀수를 선택했다면
                input_pt = first_pt # 넣을 포인트 초기화
            if hz == 2: # 만약 처음에 짝수를 선택했다면
                input_pt*=2 # 넣을 포인트에 x2
while(True):
    pass